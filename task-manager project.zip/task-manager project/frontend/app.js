document.addEventListener('DOMContentLoaded', () => {
    // API UI Elements
    const tasksHolder = document.getElementById('tasks-holder');
    const addTaskForm = document.getElementById('add-task-form');
    const addTeamForm = document.getElementById('add-team-form');
    const desktopRefreshBtn = document.getElementById('desktop-refresh-btn');
    const taskAssigneeSelect = document.getElementById('task-assignee');
    const teamListHolder = document.getElementById('team-list-holder');

    // UI Tab Navigation Elements (Mobile Views)
    const tabListBtn = document.getElementById('tab-list');
    const tabAddBtn = document.getElementById('tab-add');
    const tabTeamBtn = document.getElementById('tab-team');
    
    const viewList = document.getElementById('view-list');
    const viewAdd = document.getElementById('view-add');
    const viewTeam = document.getElementById('view-team');

    // Swipe Pull-To-Refresh configurations
    const scroller = document.getElementById('scroller-element');
    const ptrIndicator = document.getElementById('ptr-indicator');
    const ptrText = document.getElementById('ptr-text');

    // Progress Dashboard elements
    const countPending = document.getElementById('count-pending');
    const countOngoing = document.getElementById('count-ongoing');
    const countCompleted = document.getElementById('count-completed');
    const barPending = document.getElementById('bar-pending');
    const barOngoing = document.getElementById('bar-ongoing');
    const barCompleted = document.getElementById('bar-completed');

    let touchStartY = 0;
    let isTrackingPull = false;
    const dragThreshold = 80;

    let globalTeam = []; // Memory cache of active team details

    // Initial Database query
    triggerSystemDataReload();

    desktopRefreshBtn.addEventListener('click', () => {
        triggerSystemDataReload();
    });

    /* --- Core Sync Engine --- */
    async function triggerSystemDataReload() {
        await fetchTeamData();
        await fetchTaskData();
    }

    /* --- View Navigation System (Mobile View Only) --- */
    function switchMobileView(targetView) {
        if (window.innerWidth >= 1024) return;

        // Reset elements
        tabListBtn.classList.remove('active');
        tabAddBtn.classList.remove('active');
        tabTeamBtn.classList.remove('active');
        viewList.classList.remove('active');
        viewAdd.classList.remove('active');
        viewTeam.classList.remove('active');

        if (targetView === 'list') {
            tabListBtn.classList.add('active');
            viewList.classList.add('active');
        } else if (targetView === 'add') {
            tabAddBtn.classList.add('active');
            viewAdd.classList.add('active');
        } else {
            tabTeamBtn.classList.add('active');
            viewTeam.classList.add('active');
        }
    }

    tabListBtn.addEventListener('click', () => switchMobileView('list'));
    tabAddBtn.addEventListener('click', () => switchMobileView('add'));
    tabTeamBtn.addEventListener('click', () => switchMobileView('team'));

    /* --- Dynamic Pull-To-Refresh System (Mobile Only) --- */
    scroller.addEventListener('touchstart', (e) => {
        if (window.innerWidth < 1024 && scroller.scrollTop === 0) {
            touchStartY = e.touches[0].clientY;
            isTrackingPull = true;
            scroller.style.transition = 'none';
            ptrIndicator.style.transition = 'none';
        }
    }, { passive: true });

    scroller.addEventListener('touchmove', (e) => {
        if (!isTrackingPull) return;
        const currentY = e.touches[0].clientY;
        const rawDelta = currentY - touchStartY;

        if (rawDelta > 0) {
            const pullDistance = Math.min(rawDelta * 0.4, dragThreshold + 30);
            scroller.style.transform = `translateY(${pullDistance}px)`;
            ptrIndicator.style.display = 'flex';
            ptrIndicator.style.transform = `translateY(${pullDistance}px)`;

            ptrText.textContent = pullDistance >= dragThreshold ? "Release to update database" : "Pull to refresh";
        }
    }, { passive: true });

    scroller.addEventListener('touchend', async () => {
        if (!isTrackingPull) return;
        isTrackingPull = false;

        const currentPull = parseFloat(scroller.style.transform.replace(/[^\d.]/g, '')) || 0;

        scroller.style.transition = 'transform 0.3s cubic-bezier(0.1, 0.8, 0.3, 1)';
        ptrIndicator.style.transition = 'transform 0.3s cubic-bezier(0.1, 0.8, 0.3, 1)';

        if (currentPull >= dragThreshold) {
            scroller.style.transform = `translateY(${dragThreshold - 30}px)`;
            ptrIndicator.style.transform = `translateY(${dragThreshold - 30}px)`;
            ptrText.textContent = "Syncing network...";

            await triggerSystemDataReload();

            setTimeout(() => {
                scroller.style.transform = 'translateY(0px)';
                ptrIndicator.style.transform = 'translateY(0px)';
            }, 500);
        } else {
            scroller.style.transform = 'translateY(0px)';
            ptrIndicator.style.transform = 'translateY(0px)';
        }
    });

    /* --- TEAM DATABASE MANAGEMENTS --- */
    async function fetchTeamData() {
        try {
            const response = await fetch('/api/team');
            if (response.status === 200) {
                globalTeam = await response.json();
                renderTeamDirectory(globalTeam);
                populateAssigneeDropdown(globalTeam);
            }
        } catch (error) {
            console.error("Communication failure fetching team directory: ", error);
        }
    }

    function populateAssigneeDropdown(team) {
        // Keep initial option
        taskAssigneeSelect.innerHTML = '<option value="">-- No Assignee Assigned --</option>';
        team.forEach(member => {
            const opt = document.createElement('option');
            opt.value = member.id;
            opt.textContent = `${member.name} (${member.role})`;
            taskAssigneeSelect.appendChild(opt);
        });
    }

    function renderTeamDirectory(team) {
        teamListHolder.innerHTML = '';
        if (team.length === 0) {
            teamListHolder.innerHTML = `
                <div style="text-align:center; padding: 2rem; color: var(--text-secondary);">
                    No team members cataloged.
                </div>
            `;
            return;
        }

        team.forEach(member => {
            const card = document.createElement('div');
            card.className = "member-card";
            card.innerHTML = `
                <div class="member-details">
                    <span class="member-name">${escapeSecurityHTML(member.name)}</span>
                    <span class="member-access-badge">${member.accessLevel}</span>
                </div>
                <div class="member-card-inputs">
                    <div>
                        <span style="font-size:0.75rem; color:var(--text-secondary);">Role:</span>
                        <input type="text" class="card-select inline-role-input" data-id="${member.id}" value="${escapeSecurityHTML(member.role)}">
                    </div>
                    <div>
                        <span style="font-size:0.75rem; color:var(--text-secondary);">Access:</span>
                        <select class="card-select inline-access-select" data-id="${member.id}">
                            <option value="Supporting Member" ${member.accessLevel === 'Supporting Member' ? 'selected' : ''}>Supporting Member</option>
                            <option value="Administrator" ${member.accessLevel === 'Administrator' ? 'selected' : ''}>Administrator</option>
                        </select>
                    </div>
                </div>
                <div style="display: flex; justify-content: flex-end; margin-top: 0.5rem; gap: 0.5rem;">
                    <button class="btn btn-secondary btn-sm save-member-changes-btn" data-id="${member.id}">💾 Update</button>
                    <button class="btn btn-danger btn-sm remove-member-btn" data-id="${member.id}">❌ Retire</button>
                </div>
            `;
            teamListHolder.appendChild(card);
        });

        attachTeamControlActions();
    }

    function attachTeamControlActions() {
        // Handle inline team member data updates
        document.querySelectorAll('.save-member-changes-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const memberId = e.target.getAttribute('data-id');
                const card = e.target.closest('.member-card');
                const roleVal = card.querySelector('.inline-role-input').value;
                const accessVal = card.querySelector('.inline-access-select').value;

                try {
                    const response = await fetch(`/api/team/${memberId}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ role: roleVal, accessLevel: accessVal })
                    });

                    if (response.status === 200) {
                        await triggerSystemDataReload();
                        alert("Team record synchronized.");
                    } else {
                        alert("Could not update team parameters.");
                    }
                } catch (error) {
                    console.error("Communication update failure: ", error);
                }
            });
        });

        // Delete Member from Database
        document.querySelectorAll('.remove-member-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const memberId = e.target.getAttribute('data-id');
                if (!confirm("Are you sure you want to retire this team member? Assigned tasks will be set back to unassigned.")) return;

                try {
                    const response = await fetch(`/api/team/${memberId}`, { method: 'DELETE' });
                    if (response.status === 200) {
                        await triggerSystemDataReload();
                    } else {
                        alert("Could not delete team member.");
                    }
                } catch (error) {
                    console.error("Delete operation failure: ", error);
                }
            });
        });
    }

    // Register Team Member Submit
    addTeamForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const nameIn = document.getElementById('team-name');
        const accessIn = document.getElementById('team-access');
        const roleIn = document.getElementById('team-role');

        const memberData = {
            name: nameIn.value,
            accessLevel: accessIn.value,
            role: roleIn.value
        };

        try {
            const response = await fetch('/api/team', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(memberData)
            });

            if (response.status === 201) {
                nameIn.value = '';
                roleIn.value = '';
                await triggerSystemDataReload();
                switchMobileView('list');
            } else {
                const data = await response.json();
                alert(`Error: ${data.error}`);
            }
        } catch (error) {
            console.error("Critical registration network error: ", error);
        }
    });


    /* --- TASKS DATABASE MANAGEMENT & CHARTS SYSTEM --- */
    async function fetchTaskData() {
        try {
            const response = await fetch('/api/tasks');
            if (response.status === 200) {
                const tasks = await response.json();
                renderTasksList(tasks);
                calculateProgressMetrics(tasks);
            }
        } catch (error) {
            console.error("Failed to fetch operational database entries: ", error);
        }
    }

    // Calculate dynamic dashboard progress values
    function calculateProgressMetrics(tasks) {
        const total = tasks.length;
        if (total === 0) {
            countPending.textContent = "0";
            countOngoing.textContent = "0";
            countCompleted.textContent = "0";
            barPending.style.width = "0%";
            barOngoing.style.width = "0%";
            barCompleted.style.width = "0%";
            return;
        }

        const pendingCount = tasks.filter(t => t.status === 'Pending').length;
        const ongoingCount = tasks.filter(t => t.status === 'Ongoing').length;
        const completedCount = tasks.filter(t => t.status === 'Completed').length;

        countPending.textContent = pendingCount;
        countOngoing.textContent = ongoingCount;
        countCompleted.textContent = completedCount;

        // Apply percentages to visual graph bars
        barPending.style.width = `${(pendingCount / total) * 100}%`;
        barOngoing.style.width = `${(ongoingCount / total) * 100}%`;
        barCompleted.style.width = `${(completedCount / total) * 100}%`;
    }

    function renderTasksList(tasks) {
        tasksHolder.innerHTML = '';
        if (tasks.length === 0) {
            tasksHolder.innerHTML = `
                <div style="text-align:center; padding: 3rem 1rem; color: var(--text-secondary);">
                    No operations queue items registered.
                </div>
            `;
            return;
        }

        // Sort: Pending -> Ongoing -> Completed
        tasks.sort((a, b) => {
            const weights = { "Pending": 1, "Ongoing": 2, "Completed": 3 };
            return weights[a.status] - weights[b.status];
        });

        tasks.forEach(task => {
            const matchedAssignee = globalTeam.find(m => m.id === task.assignedTo);
            const assigneeName = matchedAssignee ? `${matchedAssignee.name} (${matchedAssignee.role})` : 'Unassigned';

            const card = document.createElement('div');
            card.className = `task-card ${task.status.toLowerCase()}`;
            card.innerHTML = `
                <div class="task-card-header">
                    <span class="task-title">${escapeSecurityHTML(task.title)}</span>
                    <span class="status-badge ${task.status.toLowerCase()}">${task.status}</span>
                </div>
                <div class="task-assignee-text">⚙️ Operator: <strong>${escapeSecurityHTML(assigneeName)}</strong></div>
                <div class="task-desc">${escapeSecurityHTML(task.description)}</div>
                
                <div class="task-actions">
                    <!-- Inline status modifiers dropdown -->
                    <select class="card-select action-status-select" data-id="${task.id}">
                        <option value="Pending" ${task.status === 'Pending' ? 'selected' : ''}>Pending</option>
                        <option value="Ongoing" ${task.status === 'Ongoing' ? 'selected' : ''}>Ongoing</option>
                        <option value="Completed" ${task.status === 'Completed' ? 'selected' : ''}>Completed</option>
                    </select>

                    <!-- Reassign dropdown list -->
                    <select class="card-select action-assign-select" data-id="${task.id}">
                        <option value="">Unassigned</option>
                        ${globalTeam.map(member => `<option value="${member.id}" ${task.assignedTo === member.id ? 'selected' : ''}>Assign: ${member.name}</option>`).join('')}
                    </select>

                    <button class="btn btn-danger btn-sm action-delete-btn" data-id="${task.id}">Delete</button>
                </div>
            `;
            tasksHolder.appendChild(card);
        });

        attachTaskActions();
    }

    function attachTaskActions() {
        // Change Task Status Selector
        document.querySelectorAll('.action-status-select').forEach(select => {
            select.addEventListener('change', async (e) => {
                const taskId = e.target.getAttribute('data-id');
                const targetStatus = e.target.value;

                try {
                    const response = await fetch(`/api/tasks/${taskId}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ status: targetStatus })
                    });
                    if (response.status === 200) {
                        await fetchTaskData();
                    }
                } catch (error) {
                    console.error("Communication failure updating task status: ", error);
                }
            });
        });

        // Change Task Assignee Selector
        document.querySelectorAll('.action-assign-select').forEach(select => {
            select.addEventListener('change', async (e) => {
                const taskId = e.target.getAttribute('data-id');
                const targetAssignee = e.target.value || null;

                try {
                    const response = await fetch(`/api/tasks/${taskId}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ assignedTo: targetAssignee })
                    });
                    if (response.status === 200) {
                        await fetchTaskData();
                    }
                } catch (error) {
                    console.error("Communication failure updating task assignee: ", error);
                }
            });
        });

        // Delete Task Action
        document.querySelectorAll('.action-delete-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const taskId = e.target.getAttribute('data-id');
                if (!confirm("Are you sure you want to permanently delete this task?")) return;

                try {
                    const response = await fetch(`/api/tasks/${taskId}`, { method: 'DELETE' });
                    if (response.status === 200) {
                        await fetchTaskData();
                    }
                } catch (error) {
                    console.error("Communication error during delete operation: ", error);
                }
            });
        });
    }

    // Submit New Task Form
    addTaskForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const titleIn = document.getElementById('task-title');
        const assigneeIn = document.getElementById('task-assignee');
        const descIn = document.getElementById('task-description');

        const taskData = {
            title: titleIn.value,
            assignedTo: assigneeIn.value || null,
            description: descIn.value
        };

        try {
            const response = await fetch('/api/tasks', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(taskData)
            });

            if (response.status === 201) {
                titleIn.value = '';
                descIn.value = '';
                assigneeIn.value = '';
                await fetchTaskData();
                switchMobileView('list');
            } else {
                const data = await response.json();
                alert(`Error: ${data.error}`);
            }
        } catch (error) {
            console.error("Critical registration communication error: ", error);
        }
    });

    function escapeSecurityHTML(str) {
        return str.replace(/[&<>'"]/g, 
            tag => ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                "'": '&#39;',
                '"': '&quot;'
            }[tag] || tag)
        );
    }
});